function searchRecipes() {
    const ingredient = document.getElementById("ingredient").value.trim();
    const results = document.getElementById("results");
    results.innerHTML = "";
    if (!ingredient) {
        results.innerHTML = "<p>재료를 입력하세요.</p>";
        return;
    }
    fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${ingredient}`)
        .then(response => response.json())
        .then(data => {
            if (data.meals) {
                data.meals.forEach(meal => {
                    const mealElement = document.createElement("article");
                    mealElement.innerHTML = `
                        <h3>${meal.strMeal}</h3>
                        <img src="${meal.strMealThumb}" alt="${meal.strMeal}" width="150">
                        <p>ID: ${meal.idMeal}</p>
                    `;
                    results.appendChild(mealElement);
                });
            } else {
                results.innerHTML = "<p>해당 재료로 찾은 레시피가 없습니다.</p>";
            }
        })
        .catch(error => {
            console.error("API 요청 중 오류 발생:", error);
            results.innerHTML = "<p>레시피를 불러오는 중 오류가 발생했습니다.</p>";
        });
}